<!doctype html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <title>ADMIN | RIASEC Test Admin Page</title>

      <!-- Favicon -->
      <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.svg')); ?>" />

      <!-- Library / Plugin Css Build -->
      <link rel="stylesheet" href="<?php echo e(asset('css/core/libs.min.css')); ?>" />

      <!-- Aos Animation Css -->
      <link rel="stylesheet" href="<?php echo e(asset('vendor/aos/dist/aos.css')); ?>" />

      <!-- Hope Ui Design System Css -->
      <link rel="stylesheet" href="<?php echo e(asset('css/hope-ui.min.css')); ?>" />

      <!-- Custom Css -->
      <link rel="stylesheet" href="<?php echo e(asset('css/custom.min.css')); ?>" />

      <!-- Dark Css -->
      <link rel="stylesheet" href="<?php echo e(asset('css/dark.min.css')); ?>"/>

      <!-- Customizer Css -->
      <link rel="stylesheet" href="<?php echo e(asset('css/customizer.min.css')); ?>"/>

      <!-- RTL Css -->
      <link rel="stylesheet" href="<?php echo e(asset('css/rtl.min.css')); ?>"/>


  </head>
  <body class="  ">

    <?php if(\Route::currentRouteName() === 'login' ||\Route::currentRouteName() === 'password.request' ||\Route::currentRouteName() === 'success-confirm'): ?>
        <?php echo $__env->yieldContent('content'); ?>
    <?php else: ?>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>
    <?php endif; ?>




        <!-- Wrapper End-->
    <!-- Library Bundle Script -->
    <script src="<?php echo e(asset('js/core/libs.min.js')); ?>"></script>
    

    <!-- External Library Bundle Script -->
    <script src="<?php echo e(asset('js/core/external.min.js')); ?>"></script>
    

    <!-- Widgetchart Script -->
    <script src="<?php echo e(asset('js/charts/widgetcharts.js')); ?>"></script>
    

    <!-- mapchart Script -->
    <script src="<?php echo e(asset('js/charts/vectore-chart.js')); ?>"></script>
    
    <script src="<?php echo e(asset('js/charts/dashboard.js')); ?>" ></script>
    

    <!-- fslightbox Script -->
    <script src="<?php echo e(asset('js/plugins/fslightbox.js')); ?>"></script>
    

    <!-- Settings Script -->
    <script src="<?php echo e(asset('js/plugins/setting.js')); ?>"></script>
    

    <!-- Slider-tab Script -->
    <script src=".<?php echo e(asset('js/plugins/slider-tabs.js')); ?>"></script>
    

    <!-- Form Wizard Script -->
    <script src=".<?php echo e(asset('js/plugins/form-wizard.js')); ?>"></script>
    

    <!-- AOS Animation Plugin-->
    <script src="<?php echo e(asset('vendor/aos/dist/aos.js')); ?>"></script>
    

    <!-- App Script -->
    <script src="<?php echo e(asset('js/hope-ui.js')); ?>"></script>
    

  </body>
  </html>
<?php /**PATH D:\Tugas Skripsi - Jeffry\RIASEC-ADMIN\admin_riasec_test\resources\views/layouts/app.blade.php ENDPATH**/ ?>