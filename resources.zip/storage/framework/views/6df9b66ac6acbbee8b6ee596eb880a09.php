<table id="datatable" class="table table-striped" data-toggle="data-table">
    <thead>
        <tr>
            <th>User</th>
            <th>Email</th>
            <th>Phone Number</th>
            <th>School Name</th>
            <th>Future Occupation</th>
            <th>R</th>
            <th>I</th>
            <th>A</th>
            <th>S</th>
            <th>E</th>
            <th>C</th>
            <th>Test Date</th>
        </tr>

    </thead>

    <tbody>
        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($result->name); ?></td>
                <td><?php echo e($result->email); ?></td>
                <td><?php echo e($result->phone_number); ?></td>
                <td style="min-width: 150px" class="text-wrap">
                    <?php echo e($result->school_name); ?>

                </td>
                <td><?php echo e($result->occupation_desc); ?></td>
                <?php
                    $score = json_decode($result->score, true);
                ?>
                <?php if(isset($score['REALISTIC'])): ?>
                    <td><?php echo e($score['REALISTIC']); ?></td>
                <?php elseif(isset($score['R'])): ?>
                    <td><?php echo e($score['R']); ?></td>
                <?php else: ?>
                    <td>N/A</td>
                <?php endif; ?>

                <?php if(isset($score['INVESTIGATIVE'])): ?>
                    <td><?php echo e($score['INVESTIGATIVE']); ?></td>
                <?php elseif(isset($score['I'])): ?>
                    <td><?php echo e($score['I']); ?></td>
                <?php else: ?>
                    <td>N/A</td>
                <?php endif; ?>
                <?php if(isset($score['ARTISTIC'])): ?>
                    <td><?php echo e($score['ARTISTIC']); ?></td>
                <?php elseif(isset($score['A'])): ?>
                    <td><?php echo e($score['A']); ?></td>
                <?php else: ?>
                    <td>N/A</td>
                <?php endif; ?>
                <?php if(isset($score['SOCIAL'])): ?>
                    <td><?php echo e($score['SOCIAL']); ?></td>
                <?php elseif(isset($score['S'])): ?>
                    <td><?php echo e($score['S']); ?></td>
                <?php else: ?>
                    <td>N/A</td>
                <?php endif; ?>
                <?php if(isset($score['ENTERPRISING'])): ?>
                    <td><?php echo e($score['ENTERPRISING']); ?></td>
                <?php elseif(isset($score['E'])): ?>
                    <td><?php echo e($score['E']); ?></td>
                <?php else: ?>
                    <td>N/A</td>
                <?php endif; ?>
                <?php if(isset($score['CONVENTIONAL'])): ?>
                    <td><?php echo e($score['CONVENTIONAL']); ?></td>
                <?php elseif(isset($score['C'])): ?>
                    <td><?php echo e($score['C']); ?></td>
                <?php else: ?>
                    <td>N/A</td>
                <?php endif; ?>
                <td><?php echo e(\Carbon\Carbon::parse($result->created_at)->format('Y-m-d H:i')); ?></td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <!-- <tfoot>
    <tr>
        <th>User</th>
        <th>Email</th>
        <th>Phone Number</th>
        <th>School Name</th>
        <th>Future Occupation</th>
        <th>R</th>
        <th>I</th>
        <th>A</th>
        <th>S</th>
        <th>E</th>
        <th>C</th>
    </tr>
</tfoot> -->
</table>
<?php /**PATH D:\Tugas Skripsi - Jeffry\RIASEC-ADMIN\admin_riasec_test\resources\views/components/table/resultTable.blade.php ENDPATH**/ ?>