<table
id="datatable"
class="table table-striped"
data-toggle="data-table"
>
<thead>
    <tr>
        <th>User</th>
        <th>Email</th>
        <th>Phone Number</th>
        <th>School Name</th>
        <th>Future Occupation</th>
        <th>R</th>
        <th>I</th>
        <th>A</th>
        <th>S</th>
        <th>E</th>
        <th>C</th>
        <th>Test Date</th>
    </tr>

</thead>

<tbody>
    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($result->name); ?></td>
        <td><?php echo e($result->email); ?></td>
        <td><?php echo e($result->phone_number); ?></td>
        <td
            style="min-width: 150px"
            class="text-wrap"
        >
            <?php echo e($result->school_name); ?>

        </td>
        <td><?php echo e($result->occupation_desc); ?></td>
        <?php
            $score=json_decode($result->score, true);
        ?>
        <td><?php echo e($score['R']); ?></td>
        <td><?php echo e($score['I']); ?></td>
        <td><?php echo e($score['A']); ?></td>
        <td><?php echo e($score['S']); ?></td>
        <td><?php echo e($score['E']); ?></td>
        <td><?php echo e($score['C']); ?></td>
        <td><?php echo e(\Carbon\Carbon::parse($result->created_at)->format('Y-m-d H:i')); ?></td>

    </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<!-- <tfoot>
    <tr>
        <th>User</th>
        <th>Email</th>
        <th>Phone Number</th>
        <th>School Name</th>
        <th>Future Occupation</th>
        <th>R</th>
        <th>I</th>
        <th>A</th>
        <th>S</th>
        <th>E</th>
        <th>C</th>
    </tr>
</tfoot> -->
</table>
<?php /**PATH D:\Tugas Skripsi - Jeffry\RIASEC-ADMIN\admin_riasec_test\resources\views/components/table/resulTable.blade.php ENDPATH**/ ?>