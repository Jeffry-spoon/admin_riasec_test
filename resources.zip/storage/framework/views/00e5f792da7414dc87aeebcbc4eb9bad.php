<?php echo e($slot); ?>

<?php /**PATH D:\Tugas Skripsi - Jeffry\RIASEC-ADMIN\admin_riasec_test\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>