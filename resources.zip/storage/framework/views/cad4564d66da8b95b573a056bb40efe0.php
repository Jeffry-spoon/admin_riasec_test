<?php $__env->startSection('content'); ?>
    <!-- loader Start -->
    <div id="loading">
        <div class="loader simple-loader">
            <div class="loader-body"></div>
        </div>    </div>
      <!-- loader END -->

        <div class="wrapper">
        <section class="login-content">
           <div class="row m-0 align-items-center bg-white vh-100">
              <div class="col-md-6 d-md-block d-none bg-primary p-0 mt-n1 vh-100 overflow-hidden">
                 <img src="<?php echo e(asset('images/auth/02.png')); ?>" class="img-fluid gradient-main animated-scaleX" alt="images">
              </div>
              <div class="col-md-6 p-0">
                 <div class="card card-transparent auth-card shadow-none d-flex justify-content-center mb-0">
                    <div class="card-body" :status="session('status')">
                       <a href="../../dashboard/index.html" class="navbar-brand d-flex align-items-center mb-3">
                          <!--Logo start-->
                          <!--logo End-->

                          <!--Logo start-->
                        <img src="<?php echo e(asset('images/favicon.svg')); ?>" style="width: 36px">
                          <!--logo End-->

                          <h4 class="logo-title ms-3">Admin</h4>
                       </a>
                       <h2 class="mb-2">Reset Password</h2>
                       <p>Enter your email address and we'll send you an email with instructions to reset your password.</p>
                       <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>
                          <div class="row">
                             <div class="col-lg-12">
                                <div class="floating-label form-group">
                                   <label for="email" class="form-label">Email</label>
                                   <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" aria-describedby="email" placeholder=" " name="email" value="<?php echo e(old('email')); ?>">
                                   <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                   <div class="invalid-feedback">
                                       <?php echo e($message); ?>

                                   </div>
                                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                             </div>
                          </div>
                          <button type="submit" class="btn btn-primary">Reset</button>
                       </form>
                    </div>
                 </div>
                 <div class="sign-bg sign-bg-right">
                    <svg width="280" height="230" viewBox="0 0 431 398" fill="none" xmlns="http://www.w3.org/2000/svg">
                       <g opacity="0.05">
                       <rect x="-157.085" y="193.773" width="543" height="77.5714" rx="38.7857" transform="rotate(-45 -157.085 193.773)" fill="#3B8AFF"/>
                       <rect x="7.46875" y="358.327" width="543" height="77.5714" rx="38.7857" transform="rotate(-45 7.46875 358.327)" fill="#3B8AFF"/>
                       <rect x="61.9355" y="138.545" width="310.286" height="77.5714" rx="38.7857" transform="rotate(45 61.9355 138.545)" fill="#3B8AFF"/>
                       <rect x="62.3154" y="-190.173" width="543" height="77.5714" rx="38.7857" transform="rotate(45 62.3154 -190.173)" fill="#3B8AFF"/>
                       </g>
                    </svg>
                 </div>
              </div>
           </div>
        </section>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Tugas Skripsi - Jeffry\RIASEC-ADMIN\admin_riasec_test\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>